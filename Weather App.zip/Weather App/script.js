const weatherBox = document.getElementById("weather");

const city = "Islamabad";
const apiKey = "bc1b1644131f547d334ded42a8295a0b";

const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

fetch(apiURL)
  .then(response => {
    if (!response.ok) {
      throw new Error("Weather data not found.");
    }
    return response.json();
  })
  .then(data => {
    const temperature = data.main.temp;
    const condition = data.weather[0].main;
    const cityName = data.name;
    weatherBox.innerText = `📍 ${cityName} — ${temperature}°C, ${condition}`;
  })
  .catch(error => {
    console.error("Error fetching weather:", error);
    weatherBox.innerText = "❌ Unable to fetch weather.";
  });
