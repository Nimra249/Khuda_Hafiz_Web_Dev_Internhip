import { auth } from './firebase-config.js';
import { signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value.trim();

  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    console.log("Login successful!", user);
    
    // Optionally store user's email/name
    localStorage.setItem("userEmail", email);

    // Redirect to welcome page
    window.location.href = "welcome.html";
  } catch (error) {
    alert("Login failed: " + error.message);
  }
});
