// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDKW4f_ntP3U-ipOt3GzQMZ9fu1dvax6Zo",
  authDomain: "hbbghjrgh.firebaseapp.com",
  projectId: "hbbghjrgh",
  storageBucket: "hbbghjrgh.firebasestorage.app",
  messagingSenderId: "446579510932",
  appId: "1:446579510932:web:c7b058cc21df7a6c96ee81",
  measurementId: "G-QXFJ7N2B7K"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
