let tasks = [];

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
  const saved = localStorage.getItem("tasks");
  if (saved) {
    tasks = JSON.parse(saved);
    renderTasks();
  }
}

function addTask() {
  const title = document.getElementById("task-title").value.trim();
  const desc = document.getElementById("task-desc").value.trim();
  if (!title) {
    alert("Please enter a task title.");
    return;
  }

  tasks.push({ title, desc });
  saveTasks();
  renderTasks();
  document.getElementById("task-title").value = "";
  document.getElementById("task-desc").value = "";
}

function editTask(index) {
  const newTitle = prompt("Edit Task Title:", tasks[index].title);
  const newDesc = prompt("Edit Description:", tasks[index].desc);
  if (newTitle !== null) {
    tasks[index].title = newTitle.trim();
    tasks[index].desc = newDesc.trim();
    saveTasks();
    renderTasks();
  }
}

function deleteTask(index) {
  if (confirm("Delete this task?")) {
    tasks.splice(index, 1);
    saveTasks();
    renderTasks();
  }
}

function renderTasks() {
  const list = document.getElementById("task-list");
  list.innerHTML = "";
  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <div class="task-title">${task.title}</div>
      <div class="task-desc">${task.desc}</div>
      <div class="buttons">
        <button class="edit-btn" onclick="editTask(${index})">Edit</button>
        <button class="delete-btn" onclick="deleteTask(${index})">Delete</button>
      </div>
    `;
    list.appendChild(li);
  });
}

loadTasks();
